# Maze Roll

A WebGL maze game built with Three.js and Box2dWeb.

### Launching

There are several ways to launch the game. Here is the simplest:

1. Clone or download the repository
2. Navigate to Astray's directory
3. Start 'python -m SimpleHTTPServer' in your shell
4. Open 'localhost:8000' in your browser
5. Enjoy!

### License

I don't believe in them. You can order your bits however you please.
